/* Brighten Godfrey, Intel Research Pittsburgh and UC Berkeley,
 * 6/2004 - 10/2004
 * Cleaned up May 2005
 * Some code snippets for OpenDHT interaction taken from ohchat-0.02,
 * by Brad Karp, Intel Research Pittsburgh, 4/2004
 */

#include "redir.h"

/***********************************************************************
 * Private Utilities (not defined in redir.h)
 ***********************************************************************/

#define CLIENT_LIBRARY "ReDiR++"

inline int double2nsec(double d) {
  return (int) ((d - (int) d) * 1000000000);
}

/* Returns a random double in the range [0, range) */
inline double rand_double(double range) {
  return range * ((double) rand() / (double) RAND_MAX);
}

/***********************************************************************
 * Misc. Utilities
 ***********************************************************************/

ptr<aclnt> opendht_connect(char* hostname, int port, int* ohfd_return)
{
  int ohfd;
  struct sockaddr_in myaddr;
  socklen_t myaddrlen = sizeof(struct sockaddr_in);
  ohfd = socket(PF_INET, SOCK_STREAM, 0);
  struct sockaddr_in ohsvr;
  bzero(&ohsvr, sizeof(struct sockaddr_in));
  // doesn't exist on Linux, ignored by BSD kernel (!)
  // ohsvr.sin_len = sizeof(struct sockaddr_in);
  ohsvr.sin_family = PF_INET;
  ohsvr.sin_port = htons(port);
  struct hostent *he = gethostbyname(hostname);
  if (he == NULL) {
    // FIXME: It would be good to return an errno here, but gethostbyname's
    // error numbers are not standard errno values, so an error here would
    // be confused with a connect() error below.  Should throw exception.
    warn << "Couldn't lookup hostname\n";
    return NULL;
  }
  bcopy(he->h_addr_list[0], &ohsvr.sin_addr, sizeof(struct in_addr));
  if (connect(ohfd, (struct sockaddr *) &ohsvr, sizeof(struct sockaddr_in)))
    return NULL;

  getsockname(ohfd, (struct sockaddr *) &myaddr, &myaddrlen);
  ref<axprt> ohxp = axprt_stream::alloc(ohfd);
  ref<aclnt> ohc = aclnt::alloc(ohxp, bamboo_dht_gateway_program_2);
  if (ohfd_return != NULL)
    *ohfd_return = ohfd;
  return ohc;
}

void Timer::start() {
  gettimeofday(&tv1, NULL);
}

double Timer::read() {
  struct timeval tv2;
  gettimeofday(&tv2, NULL);
  return tv2.tv_sec - tv1.tv_sec + (tv2.tv_usec - tv1.tv_usec) / 1000000.0;
}

bytes::bytes(int len) : len(len) {
  data = (byte*) malloc(len * sizeof(byte));
  bzero(data, len);
}

bytes::bytes(const byte* d, int len) : len(len) {
  data = (byte*) malloc(len * sizeof(byte));
  bcopy(d, data, len);
}

bytes::bytes(const char* null_terminated_string) {
  len = strlen(null_terminated_string);
  data = (byte*) malloc(len * sizeof(byte));
  bcopy(null_terminated_string, data, len);
}

void bytes::truncate(int new_len) {
  assert(new_len <= len);
  len = new_len;
}

bytes::~bytes() {
  free(data);
}

bool operator== (const bytes& b1, const bytes& b2) {
  return (b1.len == b2.len) && (!bcmp(b1.data, b2.data, b1.len));
}

ref<bytes> concat(ref<bytes> c1, ref<bytes> c2) {
  if (c1->len == 0)
    return c2;
  if (c2->len == 0)
    return c1;
  ref<bytes> c = New refcounted<bytes>(c1->len + c2->len);
  bcopy(c1->data, c->data, c1->len);
  bcopy(c2->data, c->data + c1->len, c2->len);
  return c;
}


/***********************************************************************
 * ID functions
 ***********************************************************************/

ReDiRID::ReDiRID() : x(0)
{ }

ReDiRID::ReDiRID(byte* buf) {
  char buf2[packed_size() + 1];
  buf2[0] = 0;
  bcopy(buf, buf2+1, packed_size());
  mpz_set_raw(&x, (const char*) buf2, packed_size() + 1);
}

ReDiRID::ReDiRID(double d)
{
  assert(0.0 <= d && d < 1.0);
  double u_long_max = 2 * (((uint64_t) LONG_MAX) + 1);
  x = bigint((u_long) (u_long_max * d));
  x <<= (160 - 32);
  assert(x < modulus().x);
}

ReDiRID::ReDiRID(bigint x) : x(x)
{ }

double ReDiRID::to_double() {
  bigint shifted = x >> (8 * (20 - sizeof(u_long)));
  u_long val = shifted.getui();
  return (double) val / (double) ULONG_MAX;
}

ReDiRID ReDiRID::succ() {
  ReDiRID res(x+1);
  res.x %= modulus().x;
  return res;
}

ReDiRID ReDiRID::dist(const ReDiRID& id2) {
  if (x <= id2.x)
    return ReDiRID(id2.x - x);
  else
    return ReDiRID((modulus().x - x) + id2.x);
}

void ReDiRID::pack(byte* buf) {
  bzero(buf, packed_size());
  size_t raw_size = mpz_rawsize(&x);
  assert(packed_size() >= raw_size - 1);
  str raw = x.getraw();
  if (packed_size() < raw_size)
    assert(raw[0] == 0); // sign bit should be in its own byte and zero
  assert(raw.len() == raw_size);
  int len = MIN(20, raw_size);
  const char* start = raw.cstr() + raw_size - len;
  bcopy(start, buf + 20 - len, len);
}

bool ReDiRID::between(ReDiRID& id1, ReDiRID& id2) {
  if (id1 == id2)
    return true;
  if (id1 == *this)
    return false;
  return id1.dist(*this) <= id1.dist(id2);
}

ReDiRID ReDiRID::modulus() {
  ReDiRID id;
  id.x = 1;
  id.x <<= 160;
  return id;
}

ReDiRID ReDiRID::random() {
  ReDiRID ret;
  for (unsigned int i = 0; i < packed_size() / sizeof(uint16_t); i++) {
	ret.x <<= 16;
    ret.x += (uint16_t) ::random();
  }
  return ret;
}

ostream& operator << (ostream& os, ReDiRID& id) {
  /* Pad with zeros so output is always same width */
  for (int i = 0; i < 40 - (int) mpz_sizeinbase(&id.x, 16); i++)
    os << "0";
  os << id.x.getstr();
  return os;
}

ReDiRID ReDiRID::zero = ReDiRID();

namespace __gnu_cxx {
  size_t hash<ReDiRID>::operator() (ReDiRID id) const {
    return hash<int>()(id.x.getsi());
  }
}

/***********************************************************************
 * AppNode
 ***********************************************************************/

#define APPNODE_PACKED_SIZE (4 + 2)

ReDiRID appnode_compute_id(byte* packed) {
  byte buf[SHA1_HASH_SIZE];
  sha1_hash(buf, (void*)packed, APPNODE_PACKED_SIZE);
  return ReDiRID(buf);
}

AppNode::AppNode(struct in_addr ip, u_int16_t port) {
  this->ip.s_addr = ip.s_addr;
  this->port = port;
  bytes packed(APPNODE_PACKED_SIZE);
  pack(packed.data);
  id = appnode_compute_id(packed.data);
}

AppNode::AppNode(byte* buf) {
  bcopy(buf, &ip.s_addr, sizeof(ip.s_addr));
  uint16_t port_n;
  bcopy(buf + sizeof(ip.s_addr), &port_n, sizeof(port_n));
  port = ntohs(port_n);
  id = appnode_compute_id(buf);
}

size_t AppNode::packed_size() {
  assert(sizeof(ip.s_addr) + sizeof(port) == APPNODE_PACKED_SIZE);
  return APPNODE_PACKED_SIZE;
}

void AppNode::pack(byte* buf) {
  bcopy(&ip.s_addr, buf, sizeof(ip.s_addr));
  uint16_t port_n = htons(port);
  bcopy(&port_n, buf + sizeof(ip.s_addr), sizeof(port_n));
}

ptr<AppNode> AppNode::unpack(byte* buf, int len) {
  if (len < APPNODE_PACKED_SIZE) {
    warn << "WARNING: couldn't unpack AppNode from buffer of length " << len << "\n";
    return NULL;
  }
  AppNode a(buf);
  return New refcounted<AppNode>(a);
}

int appnode_cmp(ref<AppNode>& a1, ref<AppNode>& a2) {
  return a1->id < a2->id;
}

ostream& operator << (ostream& os, AppNode& a) {
  os << "<id " << a.id << ", ip " << inet_ntoa(a.ip) << ", port "
    << a.port << ">";
  return os;
}


/***********************************************************************
 * TreeNodeID
 ***********************************************************************/

TreeNodeID::TreeNodeID(bytes* app_namespace, int16_t k, int16_t level,
  bigint partition)
  : app_namespace(app_namespace), k(k), level(level), partition(partition)
{ }

TreeNodeID TreeNodeID::parent() {
  assert(level > 0);
  return TreeNodeID(app_namespace, k, level - 1, partition / k);
}

size_t TreeNodeID::packed_size() {
  return app_namespace->len + sizeof(k) + sizeof(level) + mpz_rawsize(&partition);
}

void TreeNodeID::pack(byte* buf) {
  int16_t k_n = htons(k);
  int16_t level_n = htons(level);
  bcopy(app_namespace->data, buf, app_namespace->len);
  buf += app_namespace->len;
  bcopy(&k_n, buf, sizeof(k_n));
  buf += sizeof(k_n);
  bcopy(&level_n, buf, sizeof(level_n));
  buf += sizeof(level_n);
  str partition_raw = partition.getraw();
  bcopy(partition_raw, buf, partition_raw.len());
  buf += partition_raw.len();
}

void TreeNodeID::key(byte* buf) {
  bytes packed(packed_size());
  pack(packed.data);
  sha1_hash(buf, packed.data, packed.len);
}

ref<TreeNodeID> TreeNodeID::enclosing(bytes* app_namespace, int k, int level,
  ReDiRID& id, int* cell_return)
{
  bigint k_b = k, level_b = level;
  bigint m = ReDiRID::modulus().x;
  bigint num_partitions = powm(k_b, level_b, m);  // FIXME: set m to NULL??
  bigint partition_size = m / num_partitions;
  if (cell_return != NULL) {
    bigint cell_size = partition_size / k;
	bigint cell = (id.x % partition_size) / cell_size;
	int c = cell.getsi();
	assert(0 <= c && c < k);
    *cell_return = c;
  }
  bigint p = id.x / partition_size;
  return New refcounted<TreeNodeID>(app_namespace, k, level, p);
}

bool operator== (const TreeNodeID& tid1, const TreeNodeID& tid2) {
  return (tid1.level == tid2.level) && (tid1.partition == tid2.partition)
    && (tid1.k == tid2.k) && ((*tid1.app_namespace) == (*tid2.app_namespace));
}

/***********************************************************************
 * TreeNode
 ***********************************************************************/

TreeNode::TreeNode(ref<TreeNodeID> tid, ptr<struct bamboo_get_res> getres)
  : tid(tid)
{
  entries = new std::list< ref<AppNode> >[tid->k];
  
  if (getres == NULL)
    // Assume no values.
    return;
  for (size_t i = 0; i < getres->values.size(); i++) {
    ptr<AppNode> a = AppNode::unpack((byte*)getres->values[i].base(),
	  getres->values[i].size());
	if (a != NULL)
	  add_entry(a);
  }
}

int TreeNode::get_level() {
  return tid->level;
}

ptr<AppNode> TreeNode::first_geq(ReDiRID& id, bool* is_absolute_first) {
  for (int i=0; i < tid->k; i++) {
    std::list< ref<AppNode> >::iterator a = entries[i].begin();
    for (; a != entries[i].end(); a++)
      if ((*a)->id >= id) {
	    if (is_absolute_first != NULL)
          *is_absolute_first = (a == entries[i].begin());
    	return *a;
      }
  }
  return NULL;
}

ptr<AppNode> TreeNode::pred(ReDiRID& id) {
  for (int i = tid->k - 1; i >= 0; i--) {
    std::list< ref<AppNode> >::reverse_iterator a = entries[i].rbegin();
    for (; a != entries[i].rend(); a++)
      if ((*a)->id < id)
    	return *a;
  }
  return NULL;
}
    
ptr<AppNode> TreeNode::first() {
  return first_geq(ReDiRID::zero);
}

ptr<AppNode> TreeNode::last() {
  for (int i = tid->k - 1; i >= 0; i--)
    if (! entries[i].empty())
      return *(entries[i].rbegin());
  return NULL;
}
    
std::list< ref<AppNode> >* TreeNode::cell(int cell) {
  return &entries[cell];
}

std::list< ref<AppNode> >* TreeNode::cell(ReDiRID& id) {
  return &entries[cell_index(id)];
}

TreeNode::~TreeNode() {
  delete [] entries;
}

void TreeNode::add_entry(ptr<AppNode> entry) {
  int cell = cell_index(entry->id);
  // FIXME: Should check to make sure that the entry's ID is within the bounds
  // of this tree node. An attacker could place a bogus entry.  OK, so if
  // there's an attacker we have other problems.  But that would guard against
  // some bugs and would keep us from crashing.  Note cell == -1 in this case.
  assert(cell >= 0 && cell < tid->k);
  // Check to see if we already have this entry.
  std::list< ref<AppNode> >::iterator a = entries[cell].begin();
  for (; a != entries[cell].end(); a++)
    if ((*a)->id == entry->id)
      return;
  // OK, this is a new entry.
  entries[cell].push_front(entry);
  entries[cell].sort(appnode_cmp);
}

/* For debugging */
ostream& TreeNode::to_stream(ostream& os) {
  os << "    [\n";
  for (int i=0; i < tid->k; i++) {
    if (i > 0)
      os << "      ----\n";
    std::list< ref<AppNode> >::iterator a = entries[i].begin();
    for (; a != entries[i].end(); a++)
      os << "      " << **a << "\n";
  }
  os << "    ]\n";
  return os;
}

int TreeNode::cell_index(ReDiRID& id) {
  int c;
  ref<TreeNodeID> enclosing_tid =
    TreeNodeID::enclosing(tid->app_namespace, tid->k, tid->level, id, &c);
  /* Make sure this `id' really belongs to a cell in our TreeNode */
  assert(*tid == *enclosing_tid);
  return c;
}

ostream& operator << (ostream& os, TreeNode& tn) {
  return tn.to_stream(os);
}

/***********************************************************************
 * ReDiRRegistration
 ***********************************************************************/

ReDiRRegistration::ReDiRRegistration(ReDiR* r, ref<AppNode> a, int register_sec,
  ptr< callback< void > > cb_after_first_join,
  ptr< callback< void > > change_in_pred)
  : appnode(a), redir(r), register_sec(register_sec), is_first_join(true),
    cb_after_first_join(cb_after_first_join), change_in_pred(change_in_pred)
{
  cancelled = false;
  branches = 0;
  expected_level = r->expected_level;
  assert(pred==NULL);
  assert(new_pred==NULL);
}

void ReDiRRegistration::finish_initialization(ref<ReDiRRegistration> self)
{
  this->self = self;
  reg_start();
}

void ReDiRRegistration::cancel() {
  cancelled = true;
}

ptr<AppNode> ReDiRRegistration::predecessor() {
  return pred;
}

void ReDiRRegistration::increment_branches() {
  branches++;
}

void ReDiRRegistration::decrement_branches() {
  assert(branches > 0);
  branches--;
  if (branches == 0) {
    if (((new_pred == NULL) && (pred != NULL))
	  || ((new_pred != NULL) && (pred == NULL))
	  || ((new_pred != NULL) && (pred != NULL) && (new_pred->id != pred->id)))
	{
      pred = new_pred;
	  cout << "ReDiRRegistration: predecessor is now ";
	  if (pred == NULL)
	    cout << "NULL\n";
	  else
	    cout << pred->id << "\n";
	  if (change_in_pred != NULL)
	    change_in_pred();
	}
	new_pred = NULL;

    // FIXME: perhaps we should call the callback _after_ we take care of
	// our dirty cleanup work...
	if (is_first_join) {
	  is_first_join = false;
	  if (cb_after_first_join != NULL)
	    cb_after_first_join();
	}
    //cout << "Registration of " << *appnode << " completed in " << timer.read()
    //  << " seconds\n";
    if (cancelled) {
	  cout << "Cancelling registration of " << *appnode << "\n";
	  self = NULL;
    }
    else {
	  double join_time = timer.read();
      double delay = MAX(0, register_sec - join_time);
	  // A little randomization to avoid synchronization
	  if (delay >= 1.0)
	    delay += rand_double(2.0) - 1;
      if (join_time >= (redir->ttl_sec - redir->register_sec)) {
        cerr << "**** Warning: registration of " << *appnode << " took "
          << join_time << " seconds!\n";
      }
      delaycb((int)delay, double2nsec(delay), wrap(this,
        &ReDiRRegistration::reg_start));
    }
  }
}

void ReDiRRegistration::update_expected(int level) {
  expected_level = MAX(level, expected_level);
}

void ReDiRRegistration::update_predecessor(TreeNode& tn) {
  assert(branches > 0);  // should be a join in progress
  ptr<AppNode> a = tn.pred(appnode->id);
  if (tn.get_level() == 0 && a == NULL)
    // Wrap around
    a = tn.last();
  if (a != NULL && (new_pred == NULL || new_pred->id < a->id))
	  new_pred = a;
}

void ReDiRRegistration::reg_start() {
  timer.start();
  int start_level = expected_level;
  expected_level = 0;
  reg_start_0(start_level);
  //printf("reg_start level %d\n", level);
}

void ReDiRRegistration::reg_start_0(int level)
{
  increment_branches();
  assert(level >= 0);
  redir->get(level, appnode->id, wrap(this, &ReDiRRegistration::reg_start_1,
    level));
}

void ReDiRRegistration::reg_start_1(int level, ptr<TreeNode> tn)
{
  assert(level >= 0);
  //printf("reg_start_1 level %d\n", level);
  if (tn == NULL) {
    warn << "reg_start_1: Lookup failed\n";
	decrement_branches();
	return;
  }
  if (tn->first() == NULL) {
    //printf("reg_start_1() got no data\n");
    if (level > 0)
      reg_start_0(level-1);
    else
      reg_walk_up_1(0);
  }
  else {
    increment_branches();
    reg_walk_up_3(level, tn);
    increment_branches();
    reg_walk_down_2(level, tn);
  }
  decrement_branches();
}

/* Walk_up:
 * Assumes we're the first in the current level L.
 *   insert into node at level  	    <--- reg_start enters here...
 *   if level == 0, end here
 *   get embedded node at level
 *   if we're first or last in that node && level > 0  <--- ...or here
 *     recurse with level := level-1
 */
void ReDiRRegistration::reg_walk_up_1(int level)
{
  //printf("reg_walk_up_1 putting\n");
  increment_branches();
  // FIXME: should be able to just use `reg_put_res' and do the rest in
  // parallel 
  redir->put(level, appnode, wrap(this, &ReDiRRegistration::reg_walk_up_2, level));
}

void ReDiRRegistration::reg_walk_up_2(int level, bool put_failure)
{
  //printf("reg_walk_up_2 level %d\n", level);
  if (put_failure) {
    warn << "reg_walk_up_2: put failed\n";
    decrement_branches();
	return;
  }
  increment_branches();
  redir->get(level, appnode->id, wrap(this, &ReDiRRegistration::reg_walk_up_3,
    level));
  decrement_branches();
}

void ReDiRRegistration::reg_walk_up_3(int level, ptr<TreeNode> tn)
{
  //printf("reg_walk_up_3 level %d\n", level);
  if (tn == NULL) {
    warn << "reg_walk_up_3: get failed\n";
    decrement_branches();
    return;
  }
  update_predecessor(*tn);
  // FIXME: should check here to see if tn is empty.
  // (tn.first() might return NULL.)
  if (level>0 && (appnode->id <= tn->first()->id || appnode->id >= tn->last()->id))
    reg_walk_up_1(level-1);
  decrement_branches();
}

/* walk_down
 *   get embedded node at level
 *   if >= 2 entries in our cell
 *     if we're first or last
 *	 insert our entry
 *     recurse with level := level+1
 *   else
 *     update expected_level
 *     insert our entry
 *     if there are now 2 entries
 *	 run "expand" routine (below) with level := level+1
 */
void ReDiRRegistration::reg_walk_down_1(int level) {
  //printf("reg_walk_down_1 level %d\n", level);
  increment_branches();
  redir->get(level, appnode->id, wrap(this, &ReDiRRegistration::reg_walk_down_2,
    level));
}

void ReDiRRegistration::reg_walk_down_2(int level, ptr<TreeNode> tn)
{
  //printf("reg_walk_down_2 level %d\n", level);
  if (tn == NULL) {
    warn << "reg_walk_down_2: get failed\n";
    decrement_branches();
    return;
  }

  update_predecessor(*tn);
  std::list< ref<AppNode> >* cell = tn->cell(appnode->id);
  ReDiRID* id = &appnode->id;
  if (cell->size() >= 2) {
    if (*id <= (*cell->begin())->id || *id >= (*cell->rbegin())->id) {
      increment_branches();
      redir->put(level, appnode, wrap(this, &ReDiRRegistration::reg_put_res,
	    level));
    }
    reg_walk_down_1(level+1);
  }
  else {
    update_expected(level);
    increment_branches();
    redir->put(level, appnode, wrap(this, &ReDiRRegistration::reg_put_res,
	  level));
    if (cell->size() == 1 && *id != (*cell->begin())->id)
      // After our put(), there are now two unique entries in the cell,
	  // so the tree gets expanded one more level.
      reg_expand(level+1, *cell->begin());
  }
  decrement_branches();
}

void ReDiRRegistration::reg_expand(int level, ref<AppNode> appnode2) {
  //printf("reg_expand level %d\n", level);
  update_expected(level);
  increment_branches();
  redir->put(level, appnode, wrap(this, &ReDiRRegistration::reg_put_res,
    level));
  increment_branches();
  redir->put(level, appnode2, wrap(this, &ReDiRRegistration::reg_put_res,
    level));
  int cell1, cell2;
  ref<TreeNodeID> tid1 = redir->get_tid_and_cell(level, appnode->id, &cell1);
  ref<TreeNodeID> tid2 = redir->get_tid_and_cell(level, appnode2->id, &cell2);
  assert(*tid1 == *tid2);
  // FIXME: should stop at maxlevel here (and elsewhere) when that's implemented
  if (cell1 == cell2)
    reg_expand(level+1, appnode2);
}

/* Note that the put() that this is in response to was not necessarily
 * a put() of r->appnode, but it was a put associated with the registration
 * process r. */
void ReDiRRegistration::reg_put_res(int level, bool put_failure)
{
  if (put_failure)
    /* We handle the error by doing nothing -- this registration will
	 * fail but they are periodic anyway. */
    warn << "reg_put_res: put failed\n";
  decrement_branches();
}

/***********************************************************************
 * ReDiR
 ***********************************************************************/

ReDiR::ReDiR(const char* app_name, bytes* app_namespace, ref<aclnt> ohc,
      int k, int ttl_sec, int register_sec)
  : ttl_sec(ttl_sec), register_sec(register_sec)
{
  assert(k >= 2);
  this->app_name = app_name;
  this->app_namespace = app_namespace;
  this->ohc = ohc;
  this->k = k;
  this->expected_level = 2;
  // Set the max number of entries we get when we do an OpenDHT get().
  // There should be <= 2*k in steady state.  Get more just in case.
  // FIXME: check to see if we're ever reaching this limit.
  max_entries = 8*k;
  delaycb(20, 0, wrap(this, &ReDiR::keepalive));
}

void ReDiR::lookup(ReDiRID& id, callback<void, int, ptr<AppNode> >::ptr cb,
  ptr<AppNode> prev_result)
{
  if (prev_result == NULL)
    lookup_aux(id, cb, expected_level);
  else {
    ReDiRID succ = prev_result->id.succ();
    lookup_aux(succ, cb, expected_level);
  }
}

void ReDiR::lookup_aux(ReDiRID& id, callback<void, int, ptr<AppNode> >::ptr cb,
  int level, ptr<AppNode> from_above)
{
  if (level < 0)
    level = expected_level;
  get(level, id, wrap(this, &ReDiR::lookup_cb, id, level, cb, from_above));
}

void ReDiR::lookup_cb(ReDiRID id, int level,
  callback<void, int, ptr<AppNode> >::ptr cb, ptr<AppNode> from_above,
  ptr<TreeNode> tn)
{
  ptr<AppNode> successor = NULL;
  bool is_absolute_first;

  if (tn == NULL)
    return cb(-1, successor); // Note successor == NULL

  successor = tn->first_geq(id, &is_absolute_first);
  if (successor == NULL && level == 0)
    // Wrap around
    successor = tn->first_geq(ReDiRID::zero, &is_absolute_first);
  if (successor == NULL) {
    if (from_above != NULL) {
      // There is nothing here, but there was something one level higher.
      // The state of the tree is thus inconsistent; a node may be in the
      // process of joining.  Return the successor we found at the
      // next higher level as our "best guess".
      warn << "Warning: inconsistent tree state (lookup during join?)\n";
      return cb(0, from_above);
    }
    else if (level > 0)
      return lookup_aux(id, cb, level-1);
    else
      return cb(0, successor); // Note successor == NULL
  }
  else if (is_absolute_first) {
    // We have found our immediate successor
    update_expected(level);
    return cb(0, successor);
  }
  else
    // The discovered successor might not be the closest.
	// Go down a level to find possibly closer successor.
    return lookup_aux(id, cb, level+1, successor);
}
    
ref<ReDiRRegistration> ReDiR::join(struct in_addr ip, u_int16_t port,
  ptr< callback<void> > cb_after_first_join,
  ptr< callback< void > > change_in_pred)
{
  ref<AppNode> a = New refcounted<AppNode>(ip, port);
  ref<ReDiRRegistration> rr = New refcounted<ReDiRRegistration>(this, a,
    register_sec, cb_after_first_join, change_in_pred);
  rr->finish_initialization(rr);
  return rr;
}

void ReDiR::update_expected(int level) {
  //FIXME: assert(level < MAXLEVEL); when maxelevel is implemented
  level_history.push_front(level);
  if (level_history.size() > 16)
    level_history.pop_back();
  int mode_level_count_ignored;
  expected_level = mode<int>(level_history, &mode_level_count_ignored);
}

ref<TreeNodeID> ReDiR::get_tid_and_cell(int level, ReDiRID& id, int* cell_ret)
{
  return TreeNodeID::enclosing(app_namespace, k, level, id, cell_ret);
}

void ReDiR::get(int level, ReDiRID& id, callback<void, ptr<TreeNode> >::ptr cb)
{
  get_with_tid(get_tid_and_cell(level, id, NULL), cb);
}

void ReDiR::get_with_tid(ref<TreeNodeID> tid, callback<void, ptr<TreeNode> >::ptr cb)
{
  ref<struct bamboo_get_args> getargs = New refcounted<struct bamboo_get_args>;
  bzero(getargs, sizeof(struct bamboo_get_args));
  tid->key((byte*) getargs->key.base());
  getargs->application = this->app_name;
  getargs->client_library = CLIENT_LIBRARY;
  getargs->maxvals = max_entries;
  ref<struct bamboo_get_res> getres = New refcounted<struct bamboo_get_res>;
  ref<Timer> timer = New refcounted<Timer>();
  timer->start();
  ohc->call(BAMBOO_DHT_PROC_GET, getargs, getres, wrap(this,
    &ReDiR::get_cb, timer, tid, cb, getres));
}

void ReDiR::get_cb(ref<Timer> timer, ref<TreeNodeID> tid,
  callback<void, ptr<TreeNode> >::ptr cb,
  ref<struct bamboo_get_res> getres, clnt_stat err)
{
  //double latency = timer->read();
  //printf("get took %f sec\n", latency);
  // FIXME: should check type of error here and retry if appropriate.
  ptr<TreeNode> result = NULL;
  if (err)
    cout << "ReDiR::get_cb: error: " << err << "; errno=" << errno << "\n";
  else
    result = New refcounted<TreeNode>(tid, getres);
  cb(result);
}

void ReDiR::put(int level, ref<AppNode> appnode, callback<void, bool>::ptr cb)
{
  ref<struct bamboo_put_args> putargs = New refcounted<struct bamboo_put_args>;
  bzero(putargs, sizeof(struct bamboo_put_args));
  ref<TreeNodeID> tid = get_tid_and_cell(level, appnode->id, NULL);
  tid->key((byte*) putargs->key.base());
  putargs->value.setsize(appnode->packed_size());
  appnode->pack((byte*) putargs->value.base());
  putargs->application = app_name;
  putargs->client_library = CLIENT_LIBRARY;
  putargs->ttl_sec = ttl_sec;
  ref<bamboo_stat> putres = New refcounted<bamboo_stat>;

  ref<Timer> timer = New refcounted<Timer>();
  timer->start();
  
  ohc->call(BAMBOO_DHT_PROC_PUT, putargs, putres, wrap(this, &ReDiR::put_cb,
    timer, tid, cb, putres));
}

void ReDiR::put_cb(ref<Timer> timer, ref<TreeNodeID> tid,
  callback<void, bool>::ptr cb, ref<bamboo_stat> res, clnt_stat err)
{
  //double lat = timer->read();
  //printf("put took %f sec\n", lat);

  // FIXME: with the new OpenDHT API, we could be a bit more careful and retry
  // in certain cases if there's an error.
  cb(err != 0);
}

// FIXME: Currently (June 2005) OpenDHT closes connections after 30 seconds,
// even if requests are in progress.  To avoid that, we send a null RPC every
// 20 seconds.  It would be marginally better to keep track of when the last
// RPC of any type was sent, and only send this if it's been longer than 20
// seconds.

void keepalive_cb(clnt_stat err)
{
  if (err)
    fatal << "keepalive_cb: null RPC failed!\n";
}

/* 
void keepalive_cb(ptr<struct bamboo_get_res> getres, clnt_stat err)
{
  if (err)
    fatal << "keepalive_cb: get failed!\n";
  else
    warn << "keepalive get successful\n";
}
*/

void ReDiR::keepalive()
{
//  get(0, (redir_id_t) 0, wrap(keepalive_cb));
  ohc->call(BAMBOO_DHT_PROC_NULL, NULL, NULL, wrap(keepalive_cb));
  delaycb(20, 0, wrap(this, &ReDiR::keepalive));
}
