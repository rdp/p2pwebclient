#include "redir.h"
#include "choredir.h"
#include <iostream.h>

void join_complete(char* myname);
void send_msg(char* myname);
void recv_msg(ref<bytes> msg);

int main(int argc, char** argv)
    {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <arbitrary_identifying_string>\n", argv[0]);
        exit(1);
        }
    assert(strlen(argv[1]) < 100); /* just because of our buffer sizes */
    
    /* For libasync. */
    async_init();
    setbuf(stdout, NULL);

    /* Initialize Choredir */
    choredir_init("choredir_example", "planetlab13.millennium.berkeley.edu",
        5852, wrap(join_complete, argv[1]), wrap(recv_msg));

    /* Start libasync's main loop. */
    amain();
    }

// Will be called when we have joined the "DHT".
void join_complete(char* myname)
    {
    // Start sending messages now
    send_msg(myname);    
    }

// Send a message every so often
void send_msg(char* myname)
    {
    ReDiRID l, r;
    choredir_get_range(&l, &r);
    ReDiRID dest = r.succ();
    char msg[256];
    sprintf(msg, "You are the successor of %s.", myname);
    choredir_route(&dest, New refcounted<bytes>((byte*)msg, strlen(msg) + 1));
    delaycb(10, 0, wrap(send_msg, myname));
    }

void recv_msg(ref<bytes> msg)
    {
    // We are assuming here that the remote host has sent us a null-terminated
    // message so we can treat it as a standard C string.
    printf("Received \"%s\"\n", msg->data);
    }
