/* Choredir (pronounced "corridor"):  The Chord API, as used in the i3
 * Project's implementation of Chord as of June 3, 2005, implemented on
 * top of ReDiR++ in choredir.C.
 */

#ifndef _CHOREDIR_API_H
#define _CHOREDIR_API_H

#include <redir.h>

/* init: initialize chord server, provide configuration file.
 * Returns -1 on error, 0 otherwise.  Assumes that
 *
 *     async_init();
 *     setbuf(stdout, NULL);
 *
 * has already been called, and
 *
 *     amain();
 *
 * is called afterwards (perhaps not immediately, but before you expect
 * the other API calls to work).
 */
int choredir_init(char* app_name,
				  char* opendht_gateway_name,
				  int opendht_gateway_port,
				  callback<void>::ptr join_complete,
                  callback<void, ref<bytes> >::ptr recv_msg,
				  callback<void>::ptr range_update = NULL);

/* route: forward message M to the owner of key K. */
void choredir_route(ReDiRID* k, ref<bytes> msg);

/* get_range: returns the range (l,r] for which this node is responsible */
void choredir_get_range(ReDiRID* l, ReDiRID* r);

/* is_local: Does this ID belong to this server? */
int choredir_is_local(ReDiRID* x);

#endif
