#include "redir.h"
#include <iostream.h>
#include <crypt/bigint.h>

#define NUM_IDS 10
#define NUM_CLIENTS 10

void print_usage_and_exit(int argc, char **argv);
void check_ranges(const ptr<ReDiRRegistration>* clients);

struct LookupTester
    {
    int num_lookups;
    int num_lookups_remaining;
    ReDiRID ids[NUM_IDS];
    
    std::list<ReDiRID> results[NUM_IDS];
    ref<ReDiR> r;
    
    LookupTester(ref<ReDiR> r, int num_lookups);

    /* Initiate a lookup */
    void lookup();
    
    /* Handle lookup result & start the next lookup */
    void lookup_cb(int err, ptr<AppNode> result);

    ReDiRID& curr_id();
    int curr_index();
    };

int main(int argc, char** argv)
    {
    srand(time(NULL));

    /* Take care of command-line arguments */
    char* gateway_name = "planetlab10.millennium.berkeley.edu";
    int gateway_port = 5852;
    bool show_ranges = true;
    for (int i=1; i < argc; i++) {
        if (!strcmp(argv[i], "--gateway") && (i < argc-1)) {
            i++;
            gateway_name = argv[i];
            }
        else if (!strcmp(argv[i], "--port") && (i < argc-1)) {
            i++;
            gateway_port = atoi(argv[i]);
            }
        else if (!strcmp(argv[i], "--noranges"))
            show_ranges = false;
        else
            print_usage_and_exit(argc, argv);
        }

    /* For libasync. */
    async_init();
    setbuf(stdout, NULL);

    /* Open connection to OpenDHT */
    int ohfd;
    ptr<aclnt> ohc = opendht_connect(gateway_name, gateway_port, &ohfd);
    if (ohc == NULL) {
        fprintf(stderr, "Couldn't connect to gateway %s: %s\n", gateway_name,
            strerror(errno));
        exit(1);
        }

    /* Set up ReDiR library. */
    char* nm = "ReDiR++ Example";
    bytes app_namespace(nm);
    ref<ReDiR> r = New refcounted<ReDiR>(nm, &app_namespace, ohc);

    /* Get our IP address, though it doesn't really matter for this example. */
    struct sockaddr_in myaddr;
    socklen_t myaddrlen = sizeof(struct sockaddr_in);
    getsockname(ohfd, (struct sockaddr *) &myaddr, &myaddrlen);

    /* Initiate some joining ReDiR clients on some fake ports. */
    ptr<ReDiRRegistration> clients[NUM_CLIENTS];
    int baseport = 5000 + (random() % 1000);
    for (int i = 0; i < NUM_CLIENTS; i++)
        clients[i] = r->join(myaddr.sin_addr, baseport + i);
    
    printf("OK, the clients are starting to join.\n");

    if (show_ranges) {
        printf("In 30 seconds you can run `gv -watch /tmp/redir_ranges.ps'.\n");    
        /* Monitor the ID space partitioning starting in 30 seconds and 0 ns */
        delaycb(30, 0, wrap(check_ranges, clients));
        }

    /* Initiate 100 ReDiR lookups after 100 seconds and 0 nanoseconds */
    LookupTester lt(r, 100);
    printf("I'll start lookups in 100 seconds.\n");
    delaycb(100, 0, wrap(&lt, &LookupTester::lookup));

    /* Start libasync's main loop. */
    amain();
    }

void print_usage_and_exit(int argc, char **argv) {
    fprintf(stderr, "Usage: %s <options>\nSee source code for options...\n",
        argv[0]);
    exit(1);
    }

void check_ranges(const ptr<ReDiRRegistration>* clients) {
    FILE* ofp = fopen("/tmp/redir_ranges.dat", "w");
    for (int i = 0; i < NUM_CLIENTS; i++) {
        ptr<AppNode> s = clients[i]->predecessor();
        ReDiRID t = clients[i]->appnode->id;
        if (s != NULL)
            if (s->id <= t)
                fprintf(ofp, "%g %d\n%g %d\n\n", s->id.to_double(), i,
                    t.to_double(), i);
            else
                fprintf(ofp, "%g %d\n%g %d\n\n%g %d\n%g %d\n\n",
                    0.0, i, t.to_double(), i, s->id.to_double(), i, 1.0, i);
        }
    fclose(ofp);
    
    FILE* gpl = fopen("/tmp/redir_ranges.gpl", "w");
    fprintf(gpl, "set terminal postscript color\n");
    fprintf(gpl, "set output \"/tmp/redir_ranges.ps\"\n");
    fprintf(gpl, "set xlabel \"ID space\"\n");
    fprintf(gpl, "set ylabel \"ReDiR clients\"\n");
    fprintf(gpl, "plot \"/tmp/redir_ranges.dat\" notitle w lp lt 1 pt 13\n");
    fclose(gpl);
    system("gnuplot /tmp/redir_ranges.gpl");
    delaycb(20, 0, wrap(check_ranges, clients));
    }


LookupTester::LookupTester(ref<ReDiR> r, int num_lookups) : r(r)
    {
    this->num_lookups = num_lookups;
    num_lookups_remaining = num_lookups;
    for (int i = 0; i < NUM_IDS; i++)
        ids[i] = ReDiRID::random();
    }
    
void LookupTester::lookup()
    {
    r->lookup(curr_id(), wrap(this, &LookupTester::lookup_cb));
    }

/* Handle the result of a lookup */
void LookupTester::lookup_cb(int err, ptr<AppNode> result)
    {
    cout << curr_id() << " --> ";
    if (err)
        cout << "FAIL\n";
    else if (result == NULL)
        cout << "Empty Namespace\n";
    else {
        cout << *result << "\n";
        //printf("ip %d, port %d\n", result->addr.IP, result->addr.port);
        results[curr_index()].push_front(result->id);
        }
    num_lookups_remaining--;
    if (num_lookups_remaining > 0)
        delaycb(5, 0, wrap(this, &LookupTester::lookup));
    else {
        printf("Test Complete\n-------------\n");
        int total_correct = 0;
        for (int i = 0; i < NUM_IDS; i++) {
            int n = results[i].size();
            int mode_count = 0;
            mode<ReDiRID>(results[i], &mode_count);
            printf("ID %f: got %d results; %d were of most frequent result\n",
                ids[i].to_double(), n, mode_count);
            total_correct += (mode_count > n/2) ? mode_count : 0;
            }
        printf("Overall consistency: %d/%d (%.4f%%)\n", total_correct,
            num_lookups, 100 * total_correct / (double) num_lookups);
        exit(0);
        }
    }

ReDiRID& LookupTester::curr_id() {
    return ids[curr_index()];
    }

int LookupTester::curr_index() {
    return num_lookups_remaining % NUM_IDS;
    }
