/* Brighten Godfrey, IRP, 6/2004
 * Some code snippets for OpenHash interaction taken from ohchat-0.02,
 * by Brad Karp, IRP, 4/2004
 */

#ifndef _REDIR_H
#define _REDIR_H

#include "async.h"
#include "arpc.h"
#include "sha1.h"
#include "gateway_prot.h"
TYPE2STRUCT(, bamboo_stat);
#include "xdrmisc.h"
#include <iostream.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <limits.h>
#include <list>
#include <ext/hash_map>
#include <ext/hash_set>
#include <crypt/bigint.h>

/******************************************************************
 * Misc. utilities
 ******************************************************************/

#define SHA1_HASH_SIZE 20

/* Connect to specified Open DHT server.  Returns asynchronous client
 * connection, or NULL if connect() fails (in which case errno is also set).
 * Optionally returns the file descriptor in argument ohfd_return.
 * If lookup() fails, returns NULL, prints warning, and h_errno is set.
 */
ptr<aclnt> opendht_connect(char* hostname, int port, int* ohfd_return=NULL);

class Timer {
  public:
    void start();
    double read();
  private:
    struct timeval tv1;
};

/* Finds the most frequent element in a list.  Returns the element, and
 * its count in the `count' argument.  Assumes the list is not empty,
 * and the elements are hashable.
 */
template<class X> X mode(std::list<X>& lst, int* count) {
  __gnu_cxx::hash_map<X, int> sums;
  typename std::list<X>::iterator i;
  X mode_element = *lst.begin();
  for (i = lst.begin(); i != lst.end(); i++) {
    sums[*i]++;
    if (sums[*i] > sums[mode_element])
      mode_element = *i;
  }
  *count = sums[mode_element];
  return mode_element;
}

typedef unsigned char byte;

struct bytes {
  int len;
  byte* data;
	
  bytes(int length);
  bytes(const byte* d, int len);
  bytes(const char* null_terminated_string);
  void truncate(int new_len);
  ~bytes();
};

bool operator== (const bytes& b1, const bytes& b2);
ref<bytes> concat(ref<bytes> c1, ref<bytes> c2);

/******************************************************************
 * ReDiR Identifiers
 ******************************************************************/

#define REDIRIDBOOLOP(o)  inline bool operator o (const ReDiRID& id) const { \
	return x o id.x; }

class ReDiRID {
  friend class TreeNodeID;
  public:
    ReDiRID();                        /* Set to zero */
    ReDiRID(byte* buf);               /* Unpack 20 bytes of data */
    ReDiRID(double d);                /* d should be in the range [0,1) */

    double to_double();               /* For display only; loses information! */
    ReDiRID succ();                   /* `this' plus one (mod) */
    ReDiRID dist(const ReDiRID& id2); /* Clockwise distance from id1 to id2 */
    void pack(byte* buf);
    /* true iff id1 < this <= id2 (modularly) or id1==id2 */
	bool between(ReDiRID& id1, ReDiRID& id2);

    REDIRIDBOOLOP( < );
    REDIRIDBOOLOP( <= );
    REDIRIDBOOLOP( == );
    REDIRIDBOOLOP( >= );
    REDIRIDBOOLOP( > );
    REDIRIDBOOLOP( != );

    static inline size_t packed_size() {return SHA1_HASH_SIZE;}
    static ReDiRID modulus();         /* Largest ID value plus one */
    static ReDiRID random();
	static ReDiRID zero;

    ReDiRID(bigint x);
    bigint x;
};

ostream& operator << (ostream& os, ReDiRID& id);

namespace __gnu_cxx {
  template<> struct hash<ReDiRID> {
    size_t operator() (ReDiRID id) const;
  };
}

/******************************************************************
 * AppNode: a ReDiR client node
 ******************************************************************/

class AppNode {
  public:
    struct in_addr ip; /* IP address in network byte order */
    u_int16_t port;    /* Port in host byte order */
    ReDiRID id;

    AppNode(struct in_addr ip, u_int16_t port);
    size_t packed_size();
    void pack(byte* buf);

    static ptr<AppNode> unpack(byte* buf, int len);
  
  private:
    AppNode(byte* buf);
};

int appnode_cmp(ref<AppNode>& a1, ref<AppNode>& a2);
ostream& operator << (ostream& os, AppNode& a);

/******************************************************************
 * TreeNodeID and TreeNode: for internal use
 ******************************************************************/

struct TreeNodeID {
  bytes* app_namespace;
  int16_t k; /* branching factor of tree */
  int16_t level;
  bigint partition;

  TreeNodeID(bytes* app_namespace, int16_t k, int16_t level, bigint partition);
  TreeNodeID parent();
  size_t packed_size();
  void pack(byte* buf);
  void key(byte* buf); /* Write our 20-byte OpenDHT key into `buf' */

  /* Construct the ID of the TreeNode enclosing the given id at the given
   * level.  If cell_return != NULL, also returns the enclosing cell. */
  static ref<TreeNodeID> enclosing(bytes* app_namespace, int k, int level,
    ReDiRID& id, int* cell_return);
};

bool operator== (const TreeNodeID& tid1, const TreeNodeID& tid2);

class TreeNode {
  public:
    TreeNode(ref<TreeNodeID> tid, ptr<struct bamboo_get_res> getres);

    int get_level();

    /* Find the lowest-ID entry in this embedded tree node whose ID
     * is at least the specified value, if any.  If is_absolute_first != NULL,
     * returns 1 in *is_absolute_first if we can guarantee that the result
     * is the is immediate successor, not just the first in this TreeNode.
     */
    ptr<AppNode> first_geq(ReDiRID& id, bool* is_absolute_first = NULL);

    /* Find the highest-ID entry in this TreeNode whose ID is less than the
	 * specified value, if any. */
	ptr<AppNode> pred(ReDiRID& id);
    
    /* Find the lowest/highest entries in this embedded tree node. */
    ptr<AppNode> first();
    ptr<AppNode> last();
    
    std::list< ref<AppNode> >* cell(int cell);

    /* Same as cell(int c) with c = the cell enclosing id */
    std::list< ref<AppNode> >* cell(ReDiRID& id);
    ostream& TreeNode::to_stream(ostream& os);

    ~TreeNode();

  private:
    ref<TreeNodeID> tid;
    std::list< ref<AppNode> >* entries;
    void add_entry(ptr<AppNode> entry);
	/* Find the cell in which `id' lies, or -1 if it's outside this treenode. */
	int cell_index(ReDiRID& id);
};

ostream& operator << (ostream& os, TreeNode& a);

/******************************************************************
 * ReDiRRegistration: ongoing client registration process
 ******************************************************************/

class ReDiR;

class ReDiRRegistration {
  friend class ReDiR;
  public:
    const ref<AppNode> appnode;
    ReDiR* redir;
    int register_sec;

	/* ReDiRRegistrations will be instantiated by ReDiR::register_node.
	 * Don't call this directly. */
    ReDiRRegistration(ReDiR* r, ref<AppNode> a, int register_sec,
	  ptr< callback< void > > cb_after_first_join,
	  ptr< callback< void > > change_in_pred);
	
    /* Cancels this registration process.  After this is called,
     * this object should be considered destroyed.  In fact if
	 * a request is in progress it will be destroyed when we get
	 * the callback from that request. */
    void cancel();

    /* Get the predecessor of this node in the ReDiR ring.  This involves
	 * no extra OpenDHT calls; the info is obtained during the registration
	 * process.  May return NULL if registration hasn't completed yet,
	 * and will definitely do so if there are no other ReDiR clients in
	 * this namespace. */
    ptr<AppNode> predecessor();

  private:
    bool is_first_join;
    ptr< callback<void> > cb_after_first_join;
    ptr< callback<void> > change_in_pred;
    int expected_level; // Our best guess of where to start
    bool cancelled;
    int branches; /* Greater than 0 when join in progress */
    Timer timer;
	ptr<AppNode> pred;
	ptr<AppNode> new_pred;
	/* Keep a pointer to self so we're not garbage collected. */
	ptr<ReDiRRegistration> self;

	/* Call immediately after initialization to set ref to self */
    void finish_initialization(ref<ReDiRRegistration> self);

    void increment_branches();
    void decrement_branches();
	void update_expected(int level);
    void update_predecessor(TreeNode& tn);

    void reg_start();
	void reg_start_0(int level);
    void reg_start_1(int level, ptr<TreeNode> tn);
    void reg_walk_up_1(int level);
    void reg_walk_up_2(int level, bool put_failure);
    void reg_walk_up_3(int level, ptr<TreeNode> tn);
    void reg_walk_down_1(int level);
    void reg_walk_down_2(int level, ptr<TreeNode> tn);
    void reg_expand(int level, ref<AppNode> appnode2);
    void reg_put_res(int level, bool put_failure);
};

/******************************************************************
 * ReDiR: Main interface; performs lookups and registers new nodes
 ******************************************************************/

class ReDiR {
  friend class ReDiRRegistration;
  public:
    ReDiR(const char* app_name,     /* For Open DHT logging purposes, e.g.
	                                 * "your_app_name" */
	      bytes* app_namespace,     /* e.g. bytes("your_app_name") */
		  ref<aclnt> ohc,           /* connection to Open DHT */
	      int k=10,                 /* Branching factor of ReDiR tree, e.g. 10 */
		  int ttl_sec=50,           /* TTL of ReDiR entries, e.g. 60 */
		  int register_sec=20);     /* How often to refresh entries, e.g. 30 */

    /* Looks up the successor of id.  Arguments:
     *   id                  ID of which to find succesor; ignored if
	 *                       prev_result != NULL
     *   cb                  function to call upon completion
     *   prev_result         If not NULL, indicates that a previous lookup
	 *                       returned this entry but it was outdated.
	 *                       This second try may produce better results.
     * When done, calls cb with arguments
     *   int error         0 on success, -1 otherwise
     *   ptr<AppNode> a    NULL if no succ. found, otherwise contains succ
     * `lookup' should initially be called with `prev_result' set to NULL.
     * If the result `a' cannot be contacted, this may indicate a stale entry
     * (i.e. node `a' has left the system).  In this case `lookup' can be
	 * called again with `prev_result' set to `a' and a (hopefully) fresh
	 * result will be returned.  In this case the argument `id' is ignored.
	 * 
	 * Note finding no successor is not necessarily an error.
     */
    void lookup(ReDiRID& id, callback<void, int, ptr<AppNode> >::ptr cb,
                ptr<AppNode> prev_result = NULL);
    
    /* Initiates registration process of node with address <addr>.
     * The returned ReDiRRegistration may be used to cancel the process;
     * otherwise, it continues indefinately.  If the callback is not
	 * NULL, it is called when first join completes.
     */
    ref<ReDiRRegistration> join(struct in_addr ip, u_int16_t port,
	  ptr< callback< void > > cb_after_first_join = NULL,
	  ptr< callback< void > > change_in_pred = NULL);

    const int ttl_sec;
    const int register_sec;

  private:
    int k;
    int max_entries;
    std::list<int> level_history;
    int expected_level;
	const char* app_name;
    bytes* app_namespace;
    ptr<aclnt> ohc;

    void lookup_aux(ReDiRID& id, callback<void, int, ptr<AppNode> >::ptr cb,
                    int level = -1, ptr<AppNode> from_above = NULL);
    void lookup_cb(ReDiRID id, int level,
                   callback<void, int, ptr<AppNode> >::ptr cb,
                   ptr<AppNode> from_above, ptr<TreeNode> tn);

    void update_expected(int level);
    ref<TreeNodeID> get_tid_and_cell(int level, ReDiRID& id, int* cell_ret);
    void get(int level, ReDiRID& id, callback<void, ptr<TreeNode> >::ptr cb);
    void get_with_tid(ref<TreeNodeID> tid, callback<void, ptr<TreeNode> >::ptr cb);
    void get_cb(ref<Timer> timer, ref<TreeNodeID> tid,
	            callback<void, ptr<TreeNode> >::ptr cb,
                ref<struct bamboo_get_res> getres, clnt_stat err);
    void put(int level, ref<AppNode> appnode, callback<void, bool>::ptr cb);
    void put_cb(ref<Timer> timer, ref<TreeNodeID> tid,
	            callback<void, bool>::ptr cb, ref<bamboo_stat> res, clnt_stat err);
    void keepalive();
};

#endif
