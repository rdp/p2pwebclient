#include "redir.h"
#include "choredir.h"
#include <iostream.h>

void choredir_route_1(ref<bytes> msg, int retries, int error, ptr<AppNode> a);
void choredir_route_2(ref<bytes> msg, int retries, ptr<AppNode> a, int fd);
void choredir_route_3(ref<bytes> msg, int retries, ptr<AppNode> a, int fd,
    int written_so_far);
void accept_msg();
void accept_msg_1(int fd, ref<bytes> msg_so_far);
void choredir_update_range(ReDiRID* start, ReDiRID* end, ReDiRID* id);
bool choredir_range_id_is_stale();
void poll_update();

ptr<aclnt>                        choredir_ohc;
int                               choredir_msg_fd;
ptr<ReDiR>                        choredir_r;
ptr<ReDiRRegistration>            choredir_client;
callback< void >::ptr             choredir_join_complete;
callback< void, ref<bytes> >::ptr choredir_recv_msg;
callback<void>::ptr               choredir_range_update_cb;
time_t                            choredir_range_id_updated;
ReDiRID                           choredir_range_id;
ReDiRID                           choredir_pred;
ptr<bytes>                        choredir_app_name;

int choredir_init(char* app_name,
				  char* opendht_gateway_name,
				  int opendht_gateway_port,
				  callback<void>::ptr join_complete,
                  callback<void, ref<bytes> >::ptr recv_msg,
				  callback<void>::ptr range_update)
    {
    choredir_range_id_updated = 0;
    choredir_join_complete = join_complete;
    choredir_recv_msg = recv_msg;
	choredir_range_update_cb = range_update;
	choredir_app_name = New refcounted<bytes>(app_name);

    /* Open connection to OpenDHT */
    int odfd;
    choredir_ohc = opendht_connect(opendht_gateway_name, opendht_gateway_port, &odfd);
    if (choredir_ohc == NULL) {
        fprintf(stderr, "Couldn't connect to gateway %s (port %d): %s\n",
			opendht_gateway_name, opendht_gateway_port, strerror(errno));
        return -1;
        }

    /* Accept incoming messages */
    choredir_msg_fd = -1;
    int port;
    for (port=10057; port < 65535 && choredir_msg_fd < 0; port++)
        choredir_msg_fd = inetsocket(SOCK_STREAM, port);
    if (choredir_msg_fd < 0) {
        fprintf(stderr, "Couldn't create socket: ", strerror(errno));
        return -1;
        }
    port--;
	printf("choredir_init: created socket on port %d\n", port);
    make_async(choredir_msg_fd);
    listen(choredir_msg_fd, 5);
    fdcb(choredir_msg_fd, selread, wrap(accept_msg));

    /* Initialize ReDiR client */
    choredir_r = New refcounted<ReDiR>(app_name, choredir_app_name, choredir_ohc);

    /* Join our client */
    struct sockaddr_in myaddr;
    socklen_t myaddrlen = sizeof(struct sockaddr_in);
    getsockname(odfd, (struct sockaddr *) &myaddr, &myaddrlen);

    choredir_client = choredir_r->join(myaddr.sin_addr, port,
		choredir_join_complete, wrap(choredir_update_range, (ReDiRID*)NULL,
		(ReDiRID*)NULL, (ReDiRID*)NULL));

	// Hack: every 10 seconds, update range.
	// (FIXME: shouldn't actually be necessary; was just doing this
	// while testing i3 to rule out other bugs, but might be good to leav
	// in until there is some heavy use of choredir or it is merged with
	// ReDiR)
	delaycb(30, 0, wrap(poll_update));

    return 0;
    }

void poll_update()
	{
	//printf("poll_update\n");
	choredir_update_range(NULL, NULL, NULL);
	delaycb(10, 0, wrap(poll_update));
	}

void choredir_route(ReDiRID* k, ref<bytes> msg)
    {
	//printf("choredir_route: given %d-byte msg\n", msg->len);
    // Tack the key onto the beginning of the message
    ref<bytes> newmsg = New refcounted<bytes>(k->packed_size() + msg->len);
	k->pack(newmsg->data);
    bcopy(msg->data, newmsg->data + k->packed_size(), msg->len);
    
    choredir_r->lookup(*k, wrap(choredir_route_1, newmsg, 5), NULL);
    }

void choredir_route_1(ref<bytes> msg, int retries, int err, ptr<AppNode> a)
    {
    if (err)
        warn << "choredir_route: delivery failed: error on ReDiR lookup\n";
    if (a == NULL)
        warn << "choredir_route: delivery failed: no clients joined!\n";
	else {
		//cout << "choredir_route_1: given " << msg->len << "-byte msg, trying to "
		//	<< "connect to " << *a << "\n";
	    tcpconnect(a->ip, a->port, wrap(choredir_route_2, msg, retries, a));
    	}
	}

void choredir_route_2(ref<bytes> msg, int retries, ptr<AppNode> a, int fd)
    {
    if (fd < 0) {
        // FIXME: should output on warn, but can't output *a on it...
        cout << "choredir_route_2: Couldn't connect to " << *a << "\n";
        if (retries <= 0)
            warn << "choredir_route_2: retry limit exceeded; giving up\n";
        else {
            warn << "choredir_route_2: assuming down; trying successor\n";
            choredir_r->lookup(ReDiRID::zero, wrap(choredir_route_1, msg,
                retries-1), a);
            }
        return;
        }
	//printf("choredir_route_2: given %d-byte msg, waiting for writeability\n", msg->len);
    fdcb(fd, selwrite, wrap(choredir_route_3, msg, retries, a, fd, 0));
    }

void choredir_route_3(ref<bytes> msg, int retries, ptr<AppNode> a, int fd,
    int written_so_far)
    {
    fdcb(fd, selwrite, NULL);
	//printf("choredir_route_3: writing\n");
    int bytes_written = write(fd, msg->data + written_so_far,
        msg->len - written_so_far);
    if (bytes_written < 0) {
        close(fd);
        warn << "choredir_route_3: write: " << strerror(errno) << "\n";
        if (retries <= 0)
            warn << "choredir_route_3: retry limit exceeded; giving up\n";
        else {
            warn << "choredir_route_3: retrying with new TCP connection\n";
            choredir_route_1(msg, retries-1, 0, a);
            }
        return;
        }
    written_so_far += bytes_written;
	//printf("choredir_route_3: sent %d of %d byte-msg to remote choredir (%d remain)\n",
	//	bytes_written, msg->len, msg->len - written_so_far);
    if (written_so_far == msg->len)
        close(fd);
    else
        fdcb(fd, selwrite, wrap(choredir_route_3, msg, retries, a, fd,
            written_so_far));
    }

void choredir_get_range(ReDiRID *l, ReDiRID *r)
    {
    choredir_update_range(l, r, NULL);
    }

int choredir_is_local(ReDiRID *x)
    {
    ReDiRID s, t;
    choredir_update_range(&s, &t, NULL);
    return x->between(s, t);
    }

void accept_msg()
    {
    struct sockaddr_in sin;
    socklen_t slen = sizeof(struct sockaddr_in);

    int fd = accept(choredir_msg_fd, (struct sockaddr *) &sin, &slen);
    if (fd < 0)
        return;
    fdcb(fd, selread, wrap(accept_msg_1, fd, New refcounted<bytes>(0)));
    }

void accept_msg_1(int fd, ref<bytes> msg_so_far)
    {
    fdcb(fd, selread, NULL);
    ref<bytes> next_part = New refcounted<bytes>(1024);
    int bytes_read = read(fd, next_part->data, 1024);

    if (bytes_read < 0) {
        close(fd);
        warn << "accept_msg_1: read: " << strerror(errno) << "\n";
        return;
        }

    next_part->truncate(bytes_read);
    ref<bytes> msg = concat(msg_so_far, next_part);

    if (bytes_read == 0) {
        // All done with the message
        close(fd);
        // Split message into destination ID and deliverable message
        // Update our range if necessary.
        ReDiRID dest(msg->data);
		ref<bytes> deliverable = New refcounted<bytes>(msg->data+dest.packed_size(),
            msg->len - sizeof(dest));
        choredir_update_range(NULL, NULL, &dest);
		//printf("accept_msg_1: delivering message of length %d\n", deliverable->len);
        choredir_recv_msg(deliverable);
        }
    else
        // Still more; get the rest
        fdcb(fd, selread, wrap(accept_msg_1, fd, msg));
    }

/* Updates and returns the current range (or rather, our best guess at it).
 * `start' and `end' point to places to return the range.
 * `id' is NULL, or the ID of a message we've just been sent, indicating
 * that `id' must lie in our range.
 */
void choredir_update_range(ReDiRID* start, ReDiRID* end, ReDiRID* id)
    {
    // Figure out our range according to state in the embedded ReDiR tree
    ptr<AppNode> pred = choredir_client->predecessor();
    ReDiRID s;
    ReDiRID t = choredir_client->appnode->id;
    if (pred == NULL)
        s = t;
    else
        s = pred->id;
    
    // If we have recently discovered an ID outside our known range, extend
    // our range to include it.  Note that this is just a heuristic...
    // a better method would use some sort of sliding window over recent
    // messages, but an even better method is to actively ping our
    // predecessor/successor so the ReDiR tree state remains more consistent.
    // And that will appear as an option in the next version of ReDiR.
    if (id != NULL) {
        bool new_id_is_further = !id->between(choredir_range_id, t);
        if (choredir_range_id_is_stale() || new_id_is_further) {
            choredir_range_id = *id;
            choredir_range_id_updated = time(NULL);
            }
        //if (!id_between(s, *id, t))
        //    warn << "choredir_update_range: received out-of-range msg\n";
        }
    if ((!choredir_range_id_is_stale()) && (!choredir_range_id.between(s, t)))
        s = choredir_range_id;

    if (start != NULL)
        *start = s;
    if (end != NULL)
        *end = t;

	if (s != choredir_pred) {
		choredir_pred = s;
		if (choredir_range_update_cb != NULL)
			choredir_range_update_cb();
		}
    }

bool choredir_range_id_is_stale()
	{
    int tm = choredir_r->ttl_sec + choredir_r->register_sec;
    return(time(NULL) - choredir_range_id_updated >= tm);
	}

// Copy bytes in reverse order to swap endianness
void copy_bytes_rev(byte* from, byte* to, int len)
	{
	for (int i = 0; i < len; i++)
		to[i] = from[len-1-i];
	}
