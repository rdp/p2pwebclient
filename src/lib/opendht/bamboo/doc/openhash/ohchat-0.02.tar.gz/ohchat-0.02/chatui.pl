#!/usr/bin/perl

use FileHandle;
use IPC::Open2;
use Tk;

my $mw = MainWindow->new();
my $t = $mw->Scrolled('Text');
$t->pack(-expand => 1, -fill => 'both');
#$t->insert(end, "foo");
my $e = $mw->Text(-height => 4, -width => 80, -wrap => 'word');
$e->pack(-expand => 1, -fill => 'both');
$e->bind('<KeyPress-Return>', \&sendmsg);
$e->markSet('strend', '1.0');
$e->markGravity('strend', right);

$pid = open2(*readme, *writeme, "./chat $ARGV[0] 5852 $ARGV[1] 9090");
writeme->autoflush();
$mw->fileevent(readme, "readable", \&chatin);
my $outmsg = "";
$mw->MainLoop();

sub sendmsg {
    my $sendme = $e->get('1.0', 'strend');
    $outmsg .= $sendme;
    $mw->fileevent(writeme, "writable", \&chatout);
    $e->delete('1.0', 'strend');
    $e->markSet('strend', '1.0');
    $e->markGravity('strend', right);
}

sub chatout {
    my $written = 0;

    if (length($outmsg)) {
	if( $written = syswrite(writeme, $outmsg) ) {
	    $outmsg = substr($outmsg, $written);
	}
	else {
	    exit(-1);
	}
    }
    else {
	$mw->fileevent(writeme, "writable", undef);
    }
}
sub chatin {
    my $buf;

    if (sysread(readme, $buf, 2048)) {
	$t->insert(end, $buf);
    }
    else {
	exit(-1);
    }
}
