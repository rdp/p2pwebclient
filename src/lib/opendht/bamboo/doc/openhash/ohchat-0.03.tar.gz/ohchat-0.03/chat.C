// Brad Karp, IRP, 4/2004

#include "async.h"
#include "arpc.h"
#include "sha1.h"
#include "gateway_prot.h"
TYPE2STRUCT(, bamboo_stat);
#include "xdrmisc.h"
#include <iostream.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#define APPLICATION    "ohchat-0.03"
#define CLIENT_LIBRARY "sfs-arpc"

// trivial chat client for OpenHash.
// args:
//    openhash-svr (string)
//    openhash-port (int)
//    myid (string)
//    myip (string)
//    myport (int)
//
// put()s (H(myid), {myip, myport}) (no refresh yet!)
// listens on myip:myport
// dumps any received messages to stdout
// takes single lines of input of the form:
//   destid msg
// where
//   destid is the destination (user) id
//   msg is the message to send

struct im {
  char srcid[20];
  char msgtext[256];
};

struct svrvalue {
  struct in_addr IP;
  u_int16_t port;
};

void putres(bamboo_stat *res, clnt_stat err) {
  if (err) cout << "server: " << err << " " << errno << "\n";
  
  else if (*res != BAMBOO_OK) warn << "Bamboo error\n";
  //else warn << "put() succeeded.\n";
}

void nullres(bamboo_stat *res, clnt_stat err) {
  if (err) cout << "server: " << err << " " << errno << "\n";
  
  else if (*res != BAMBOO_OK) cout << "Bamboo error\n";
  else cout << "null() succeeded.\n";
}

// need to parse user input: <dstid> <msg>\n
//   completeness: read until \n, buffer remainder
//   then get() appropriate IP/port
//   then send msg
//   no caching for now...
// need to read *complete* msgs from wire
//   completeness: fixed-length msg size (simplicity)
//   then print them to stdout

void msg_in(int fd, ref<struct im> themsg, ref<u_int32_t> currlen)
{
  int n = read(fd, ((char *)&*themsg) + *currlen,
	       sizeof(struct im) - *currlen);
  *currlen += n;

  if (n == 0) {
    // premature EOF
    fdcb(fd, selread, NULL);
    close(fd);
    return;
  }
  if (*currlen == sizeof(struct im)) {
    // done with the message!
    cout << themsg->srcid << ": " << themsg->msgtext << "\n";
    fdcb(fd, selread, NULL);
    close(fd);
    return;
  }
}

void accept_msg(int fd)
{
  struct sockaddr_in sin;
  socklen_t slen = sizeof(struct sockaddr_in);

  int cs = accept(fd, (struct sockaddr *) &sin, &slen);

  ref<struct im> newim = New refcounted<struct im>;
  bzero(newim, sizeof(struct im));
  ref<u_int32_t> newlen = New refcounted<u_int32_t>;
  *newlen = 0;
  fdcb(cs, selread, wrap(msg_in, cs, newim, newlen));
}

void imwrite(ref<suio> imsuio, int fd)
{
  if (imsuio->output(fd) < 0) {
    cout << strerror(errno) << "\n";
    return;
  }
  if (!imsuio->resid()) {
    fdcb(fd, selwrite, NULL);
    close(fd);
  }
}

void imconnected(ref<suio> im, int fd)
{
  if (fd < 0)
    return;
  fdcb(fd, selwrite, wrap(imwrite, im, fd));
}

void getres(ref<suio> im, ref<aclnt> ohc,
	    ref<struct bamboo_get_res> getrpcres, clnt_stat err)
{
  if (err) cout << "server: " << err << " " << errno << "\n";
  else if (getrpcres == NULL) cout << "[Unknown user.]\n";
  else if (getrpcres->values.size() == 0) cout << "[Unknown user.]\n";
  else {
    // warn << "get() succeeded.\n";
    // warn << "found " << getrpcres->values.size() << " values.\n";
    // warn << "first val len " << getrpcres->values[0].size() << ".\n";
    ref<struct svrvalue> svr = New refcounted<struct svrvalue>;
    bcopy(getrpcres->values[0].base(), svr, sizeof(struct svrvalue));
    // warn << "server addr: " << inet_ntoa(svr->IP) << ".\n";
    // warn << "server port: " << ntohs(svr->port) << ".\n";
    tcpconnect(svr->IP, ntohs(svr->port), wrap(imconnected, im));
  }
}

char inbuf[4096];                                // accumulate user input
u_int32_t inlen = 0;                             // stored input length

void userinput(ref<aclnt> ohc, char *myid)
{
  if (inlen == 4096) {
    // full buffer, but found no terminator. flush the buffer.
    inlen = 0;
  }
  int n = read(0, inbuf + inlen, 4096 - inlen);
  inlen += n;

  // warn << "read " << n << " new chars\n";
  if (n == 0) {
    // EOF
    exit(-1);
  }

  // find a newline in the input, if any; it's a terminator
  unsigned int i = 0;
  while (i < inlen) {
    if (inbuf[i] == '\n') {
      // warn << "found a command line terminator\n";
      char dstid[20];
      struct im newim;
      bzero(&newim, sizeof(struct im));
      // preceding data should be {dstid, outmsg}
      (void) sscanf(inbuf, "%19s", dstid);
      // rest up through i should be outmsg
      bcopy(inbuf + strlen(dstid) + 1, newim.msgtext,
	    min(sizeof(newim.msgtext) - 1, i - strlen(dstid) - 1));
      strncpy(newim.srcid, myid, sizeof(newim.srcid) - 1);
      newim.msgtext[sizeof(newim.msgtext) - 1] = '\0';
      // prepare a get for the appropriate user's IP/port
      ref<struct bamboo_get_args> newget =
	New refcounted<struct bamboo_get_args>;
      bzero(newget, sizeof(struct bamboo_get_args));

      sha1_hash(newget->key.base(),
		(const unsigned char *) dstid, strlen(dstid));

      newget->application = APPLICATION;
      newget->client_library = CLIENT_LIBRARY;

      newget->maxvals = 1;
      ref<struct bamboo_get_res> newgetres =
	New refcounted<struct bamboo_get_res>;
      ref<suio> imsuio = New refcounted<suio>;
      imsuio->copy(&newim, sizeof(struct im));
      ohc->call (BAMBOO_DHT_PROC_GET, newget, newgetres, wrap(getres, imsuio,
							      ohc, newgetres));
      if (strcmp(dstid, myid)) {
	cout << myid << ": " << newim.msgtext << "\n";
      }
      // pull rest of buffer back to start
      bcopy(inbuf + i + 1, inbuf, inlen - i);
      inlen -= i + 1;
      // restart search for terminators on remaining buffered text
      i = 0;
    }
    else {
      i++;
    }
  }
}

void name_reregister(ref<aclnt> ohc, ref<struct bamboo_put_args> putme,
		   ref<bamboo_stat> res)
{
  //warn << "name_reregister\n";
  (void) delaycb(120, 0, wrap(name_reregister, ohc, putme, res));
  ohc->call (BAMBOO_DHT_PROC_PUT, putme, res, wrap(putres, res));
}

void first_register_res(ref<aclnt> ohc, ref<struct bamboo_put_args> putme,
			 ref<bamboo_stat> res, clnt_stat err)
{
  putres(res, err);
  cout << "[Registered ID]\n";
  (void) delaycb(90, 0, wrap(name_reregister, ohc, putme, res));
}

int main(int argc, char **argv)
{
  if (argc != 5) {
    printf("usage:\n");
    printf("%s <OH servname> <OH servport> <mychatID> <localmsgport>\n",
	   argv[0]);
    exit(-1);
  }
  setbuf(stdout, NULL);
  // start listening for inbound IMs
  int imfd = inetsocket(SOCK_STREAM, atoi(argv[4]));
  make_async(imfd);
  listen(imfd, 5);

  // establish connection to OpenHash server
  int ohfd;
  struct sockaddr_in myaddr;
  socklen_t myaddrlen = sizeof(struct sockaddr_in);
  ohfd = socket(PF_INET, SOCK_STREAM, 0);
  struct sockaddr_in ohsvr;
  bzero(&ohsvr, sizeof(struct sockaddr_in));
  // doesn't exist on Linux, ignored by BSD kernel (!)
  // ohsvr.sin_len = sizeof(struct sockaddr_in);
  ohsvr.sin_family = PF_INET;
  ohsvr.sin_port = htons(atoi(argv[2]));
  struct hostent *he = gethostbyname(argv[1]);
  bcopy(he->h_addr_list[0], &ohsvr.sin_addr, sizeof(struct in_addr));
  connect(ohfd, (struct sockaddr *) &ohsvr, sizeof(struct sockaddr_in));
  getsockname(ohfd, (struct sockaddr *) &myaddr, &myaddrlen);

  ref<axprt> ohxp = axprt_stream::alloc(ohfd);
  ref<aclnt> ohc = aclnt::alloc(ohxp, bamboo_dht_gateway_program_2);

  // prepare an id registration put() for OpenHash
  ref<struct bamboo_put_args> putarg = New refcounted<struct bamboo_put_args>;
  bzero(putarg, sizeof(struct bamboo_put_args));
  ref<bamboo_stat> res = New refcounted<bamboo_stat>;
  
  sha1_hash(putarg->key.base(), (const unsigned char *) argv[3],
	    strlen(argv[3]));
  
  struct svrvalue mysvr;
  mysvr.IP = myaddr.sin_addr;
  mysvr.port = htons(atoi(argv[4]));

  putarg->value.setsize(sizeof(struct svrvalue));
  bcopy(&mysvr, putarg->value.base(), sizeof(struct svrvalue));
  putarg->ttl_sec = 120;

  putarg->application = APPLICATION;
  putarg->client_library = CLIENT_LIBRARY;

  // first-time registration of ID in OpenHash
  ohc->call (BAMBOO_DHT_PROC_PUT, putarg, res, wrap(first_register_res, ohc,
						    putarg, res));
  //ohc->call (BAMBOO_DHT_PROC_NULL, 0, &res, wrap(nullres, &res));

  // register for callbacks on stdin readable
  bzero(inbuf, sizeof(inbuf));
  fdcb(0, selread, wrap(userinput, ohc, argv[3]));

  // register for callbacks on inbound message receipt
  fdcb(imfd, selread, wrap(accept_msg, imfd));

  amain();
}
